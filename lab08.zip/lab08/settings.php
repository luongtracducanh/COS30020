<?php
$host = "feenix-mariadb.swin.edu.au";
$user = "s103488117";
$pswd = "181203";
$dbnm = "s103488117_db";
?>