<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <h1>Lab03 Task 3 - Prime Number</h1>
    <hr>
    <form action="primenumber.php" method="get">
        <p>Year: <input type="text" name="num" /></p>
        <input type="submit" value="Check for Prime Number" />
    </form>
</body>

</html>