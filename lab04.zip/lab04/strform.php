<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta name="description" content="Web application development" />
    <meta name="keywords" content="PHP" />
    <meta name="author" content="Your Name" />
    <title>TITLE</title>
</head>

<body>
    <h1>Web Programming Form - Lab 4</h1>
    <form action="strprocess.php" method="post">
        <input type="text" name="str" />
        <input type="submit" value="Submit" />
    </form>
</body>

</html>